#!/bin/bash
set -e

echo "Updating system..."
sudo yum update -y
sudo yum install -y python3 postgresql

echo "Installing Flask and dependencies..."
sudo pip3 install flask psycopg2-binary

echo "Creating Flask app..."
mkdir -p /home/ec2-user/flask-app
cd /home/ec2-user/flask-app

cat <<EOL > app.py
from flask import Flask
import psycopg2

app = Flask(__name__)

def get_student():
    conn = psycopg2.connect(
        dbname="studentdb",
        user="admin",
        password="password1234",
        host="your-rds-endpoint",
        port="5432"
    )
    cur = conn.cursor()
    cur.execute("SELECT name, age FROM students LIMIT 1;")
    student = cur.fetchone()
    conn.close()
    return student

@app.route("/")
def home():
    student = get_student()
    return f"Student: {student[0]}, Age: {student[1]}"

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=80)
EOL

echo "Fetching RDS endpoint from Terraform..."
RDS_ENDPOINT=$(terraform output -raw rds_endpoint)
sed -i "s/your-rds-endpoint/$RDS_ENDPOINT/g" app.py

nohup python3 app.py > output.log 2>&1 &